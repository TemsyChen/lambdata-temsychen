"""Lambdata - collection of Data Science helper functions"""

# accessing libraries through pipenv
import pandas as pd
import numpy as np

FAVORITE_NUMBERS = [77, 107, 55, 12, 3.14, 2.71]

def df_cleaner(df):
    """Cleans a DF"""
    #TODO - implement df_cleaner
    pass