# lambdata-temsychen
A package created in Lambda School Unit 3 Sprint 1 Module 1 to learn about packages
